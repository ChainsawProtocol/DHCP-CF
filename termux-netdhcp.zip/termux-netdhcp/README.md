# Termux Network DHCP Tool

An IPv4 DHCP/DNS toolkit with an optional Cloudflare Tunnel and an
Access-authenticated HTTP gateway. Version 1.0.0.

**DNS:** `1.1.1.1` primary, `1.0.0.1` alternate. **DHCP stays on your LAN.**
The tunnel publishes the HTTP gateway; it does not transport DHCP broadcasts
or tunnel all of the phone's Internet traffic.

| Feature | What it does | Root needed |
| --- | --- | --- |
| DNS diagnostics | Queries Cloudflare over verified HTTPS, with alternate fallback | No |
| Android DNS help | Shows the system Private DNS setting | No |
| Network doctor | Reports available tools, addresses and routes when Android permits | No |
| DHCP configuration | Generates a constrained DHCP-only dnsmasq configuration | No |
| DHCP service | Assigns IPv4 leases and advertises both DNS resolvers on your LAN | Yes |
| Cloudflare Tunnel | Connects a named public hostname to the local gateway | No |
| HTTP authentication | Verifies Cloudflare Access application JWTs before forwarding | No |
| Traffic checks | Limits requests and scores a few suspicious request patterns | No |

## 1. Install in Termux

Extract this directory under your Termux home directory. Shared Android
storage can prevent executable files and virtual environments from working.
If the archive is in Downloads, one installation path is:

```bash
pkg install unzip
termux-setup-storage
unzip "$HOME/storage/downloads/termux-netdhcp.zip" -d "$HOME"
cd "$HOME/termux-netdhcp"
bash install-termux.sh
./ndhcp doctor
./ndhcp dns query example.com
```

The installer installs dependencies from your configured Termux and Python
repositories and creates a local virtual environment. It does not start
services or change Android network settings. If the repository lacks the
prebuilt `python-cryptography` package, it installs build dependencies for pip.
For the optional root-only DHCP component, run:

```bash
bash install-termux.sh --with-dhcp
```

On Linux for development, use Python 3.11 or later:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
bash ndhcp doctor
```

The launcher's shebang targets Termux. On Linux invoke it with `bash ndhcp`.
Run the gateway and tunnel as a normal user; both commands refuse root.

## 2. DNS setup

```bash
./ndhcp dns query example.com --type AAAA
./ndhcp dns android
```

Queries use `https://1.1.1.1/dns-query`, then `https://1.0.0.1/dns-query` on
transport/resolver failure. TLS certificate verification stays enabled.
NXDOMAIN is returned as a negative answer, with exit status 3. Both endpoints
must be reachable for fallback to help. No plaintext fallback is used.

For the phone itself, Android 9+ offers **Settings > Network & internet >
Private DNS > Private DNS provider hostname**. Enter `one.one.one.one`.
Menus vary by phone. For a router's IPv4 DNS settings, use `1.1.1.1` and
`1.0.0.1`. This tool does not alter Android's system resolver.

DHCP advertises DNS using option 6. Clients can choose either resolver;
ordering does not guarantee primary/backup behavior. Advertising the IPs
does not encrypt clients' DNS. These standard resolvers do not provide
the malware filtering of Cloudflare's separate Families resolvers.

## 3. Configure Cloudflare Access and a named Tunnel

You need a Cloudflare account, a domain managed in that account, and a
Cloudflare Zero Trust team. No Cloudflare credentials are included in this
download. Replace `net.example.com`, `YOUR_TEAM`, `YOUR_AUD`, and
`TUNNEL_UUID` below with your real values.

1. In Cloudflare Zero Trust, create an **Access self-hosted application** for
   the entire `net.example.com` hostname, covering every path. Add an Allow
   policy for the people who should use it. Copy the application's AUD tag
   and your team name from `YOUR_TEAM.cloudflareaccess.com`.
2. For automated clients, use an Access **Service Auth** policy and service
   tokens instead. The gateway supports the signed `common_name` identity
   in these tokens. Do not add a Bypass policy to this application.
3. Authenticate cloudflared and create a locally managed tunnel:

```bash
cloudflared tunnel login
cloudflared tunnel create netdhcp
```

The second command prints a tunnel UUID and creates its credentials JSON.
Keep that file and cloudflared's account certificate private.

Create matching gateway and tunnel settings:

```bash
./ndhcp init \
  --team YOUR_TEAM \
  --aud YOUR_AUD \
  --hostname net.example.com

./ndhcp gateway check --config gateway.json

./ndhcp tunnel config \
  --settings gateway.json \
  --id TUNNEL_UUID \
  --output cloudflared.yml

cloudflared tunnel route dns TUNNEL_UUID net.example.com
```

The default credentials path is `~/.cloudflared/TUNNEL_UUID.json`. Supply
`--credentials /absolute/path/to/credentials.json` if yours differs.
The generated tunnel config requires Access validation in cloudflared,
routes only the selected hostname to `127.0.0.1:8787`, and returns 404 for
other hostnames. The gateway independently verifies the JWT as well.
Keep Access configured before starting the tunnel.

Run these in **two Termux sessions** and leave them open:

```bash
# Session A
cd "$HOME/termux-netdhcp"
./ndhcp gateway run --config gateway.json
```

```bash
# Session B
cd "$HOME/termux-netdhcp"
./ndhcp tunnel run --config cloudflared.yml
```

Visit `https://net.example.com` and sign in through Access. With no upstream
configured, `/` returns an authenticated status response. The authenticated
health endpoint is `/__netdhcp/health`.

To protect an existing application listening on `127.0.0.1:8080`, recreate
the gateway settings with the same team, AUD, hostname and port:

```bash
./ndhcp init --team YOUR_TEAM --aud YOUR_AUD \
  --hostname net.example.com \
  --upstream http://127.0.0.1:8080 --force
```

Restart the gateway after changing its settings. If you change its port,
team, AUD or hostname, regenerate the tunnel config and restart the tunnel
too. Bind the application itself to loopback and configure its public base
URL as `https://net.example.com`. Absolute upstream redirect URLs and cookie
domains are not rewritten.

The gateway supports buffered HTTP requests and responses. It does not
support WebSockets, SSE, streaming downloads or compressed request bodies.
Loopback upstreams are restricted to literal `127.0.0.1` or `::1`, with an
explicit port. Other apps on the same phone may be able to reach a loopback
upstream directly; use upstream authentication or stronger OS isolation if
those local callers are untrusted. An upstream must not treat an identity
header as proof of authentication when it also accepts other local callers.

## 4. Optional DHCP server on a controlled LAN

DHCP serving needs root, a compatible Android kernel/SELinux policy, and an
interface already configured for your LAN. Root alone does not guarantee
that Android allows this. The normal Wi-Fi DHCP client remains managed by
Android; the tool does not renew the phone's own lease.

Use a dedicated interface/network you control, with **no other DHCP server**.
Android's hotspot service may already provide DHCP. The tool checks for a
local listener on UDP 67, but cannot detect every DHCP server elsewhere on
the LAN. It does not stop Android services, assign interface addresses,
enable tethering, or create NAT/Internet forwarding rules.

Example: a dedicated interface named `eth0` already has `192.168.50.1/24`,
and that address is also the network's actual router. Adjust all these
values to your real topology:

```bash
./ndhcp dhcp config \
  --interface eth0 \
  --subnet 192.168.50.0/24 \
  --server 192.168.50.1 \
  --router 192.168.50.1 \
  --start 192.168.50.50 \
  --end 192.168.50.100 \
  --lease 12h \
  --output dhcp.conf
```

Review `dhcp.conf`. The pool excludes the server and router and advertises
`1.1.1.1,1.0.0.1`. A DNS server is disabled with `port=0`. To start it in
the foreground from Termux:

```bash
su -c "PATH='$PREFIX/bin:/system/bin' '$PREFIX/bin/bash' '$PWD/ndhcp' dhcp serve --config '$PWD/dhcp.conf' --isolated-lan"
```

Only the DHCP process runs as root; it stays root to access Android's
interface and the private lease directory. The runner validates the config,
checks the selected interface address/prefix and local UDP 67, tests
dnsmasq's syntax, and starts a snapshot of the approved directives. It
rejects arbitrary added dnsmasq directives. Regenerate the config to change
its settings.

Connect a test client on that LAN, request an IPv4 lease and inspect it:

```bash
./ndhcp dhcp leases --file dhcp-state/dnsmasq.leases
```

The advertised router must already route traffic. A DHCP lease by itself
does not provide Internet access. IPv6 SLAAC, DHCPv6 and router
advertisements are outside this tool's scope.

## 5. Authentication and suspicious traffic checks

`ALGORITHMS.md` describes the verification sequence, rate limiter and
pattern scores. Code is in `netdhcp/security.py` and `netdhcp/gateway.py`.
The default limits are:

| Control | Default |
| --- | --- |
| Global token bucket | 30 requests/second, burst 60 |
| Verified identity bucket | 5 requests/second, burst 20 |
| Active identity entries | At most 2048 |
| Request target | At most 8192 characters |
| Request headers at Waitress | At most 32 KiB |
| Request body | At most 1 MiB |
| Text body inspected for patterns | First 64 KiB |
| Buffered upstream response | At most 8 MiB |
| Upstream socket timeout | 5 seconds per socket operation |
| JWT clock leeway | 15 seconds |
| Key-set cache / unknown-key refresh cooldown | 300 / 30 seconds |
| Pattern blocking threshold | Score 5 |

Edit `gateway.json` to tune the configurable limits, then restart. To limit
access locally to specific signed identities, populate `allowed_identities`
with `user:<sub>` and/or `service:<common_name>`. An empty list accepts
identities authorized by the configured Access application. These are
signed claim values, not email-header values.

Test sample patterns without making a web request:

```bash
./ndhcp traffic-check '/%252e%252e/secret'
./ndhcp traffic-check '/api/items?q=hello'
```

Test the running origin without a token:

```bash
curl -i -H 'Host: net.example.com' http://127.0.0.1:8787/
```

Expect HTTP 401. Fake `Cf-Ray`, `Cf-Connecting-IP` or user-email headers
do not change that result. Authentication verifies a bearer identity;
it does **not** prove that a request is harmless. The pattern checks are
limited heuristics with false positives and evasions. This tool does not
intercept other apps' HTTPS, perform malware scanning, install Cloudflare
WAF rules or authenticate arbitrary Internet traffic. Use appropriate
application validation and available Cloudflare edge protections too.

Audit records go to stderr as JSON. They include status, signal names,
request ID and a hash of the verified identity. The toolkit's audit records
omit URLs, query strings, bodies, tokens and email addresses. Upstream and
cloudflared logs are independent; avoid their verbose/debug modes with
real credentials.

## Stop, troubleshoot and verify

Press Ctrl-C in each foreground session to stop its service. Tunnel/DNS
records remain in your Cloudflare account. No boot service is installed.
Android can suspend background Termux; if needed, use `termux-wake-lock`
while serving and `termux-wake-unlock` when finished.

| Result | What to check |
| --- | --- |
| Origin 401 | Access JWT missing, invalid, expired, wrong issuer/AUD, or denied by local identity list |
| Origin 403 | Pattern threshold or cross-site write check |
| Origin 421 | Host header differs from configured hostname |
| Origin 429 | Global or identity rate limit; wait for refill |
| Origin 503 | Signing keys unavailable; check connectivity and retry after 30 seconds |
| Origin 502 | Upstream unavailable, too slow, malformed or response too large |
| Tunnel fails to start | Credentials path, Access settings, DNS route or cloudflared config validation |
| DHCP fails | Root/SELinux, interface address/prefix, package availability, or existing DHCP |

Run the automated checks:

```bash
.venv/bin/python -m unittest discover -s tests -v
```

See `TEST_REPORT.md` for what was verified in this build. A live Android
device, DHCP lease exchange and real Cloudflare account were not available
for integration testing. Before relying on it, validate one real client
lease and one allowed/denied Access session on your own setup.

## Primary references

- [Cloudflare Access JWT validation](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/)
- [Access application token, including service identities](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/application-token/)
- [Locally managed Tunnel setup](https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/do-more-with-tunnels/local-management/create-local-tunnel/)
- [Tunnel Access origin parameters](https://developers.cloudflare.com/api/resources/zero_trust/subresources/tunnels/subresources/cloudflared/)
- [Android Private DNS](https://developers.cloudflare.com/1.1.1.1/setup/android/)
- [Cloudflare DNS JSON queries](https://developers.cloudflare.com/1.1.1.1/encryption/dns-over-https/make-api-requests/dns-json/)
- [dnsmasq manual](https://thekelleys.org.uk/dnsmasq/docs/dnsmasq-man.html)
- [PyJWT API](https://pyjwt.readthedocs.io/en/latest/api.html)
- [Waitress](https://docs.pylonsproject.org/projects/waitress/en/latest/)
