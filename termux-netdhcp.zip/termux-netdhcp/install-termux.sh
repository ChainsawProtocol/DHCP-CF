#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
umask 077
tool_directory="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
with_dhcp=false
case "${1:-}" in
    "") ;;
    --with-dhcp) with_dhcp=true ;;
    *) printf '%s\n' 'Usage: bash install-termux.sh [--with-dhcp]' >&2; exit 2 ;;
esac
if [[ $(id -u) == 0 ]]; then
    printf '%s\n' 'Run the installer as the normal Termux user, not root.' >&2
    exit 2
fi
if ! command -v pkg >/dev/null || [[ -z ${PREFIX:-} ]]; then
    printf '%s\n' 'This installer requires Termux. For Linux, see README.md.' >&2
    exit 2
fi
pkg update -y
pkg install -y python cloudflared iproute2
if apt-cache show python-cryptography >/dev/null 2>&1; then
    pkg install -y python-cryptography
else
    # Some Termux repositories require cryptography to be built by pip.
    pkg install -y rust clang make libffi openssl pkg-config
fi
if [[ $with_dhcp == true ]]; then
    pkg install -y root-repo
    pkg install -y dnsmasq
fi
python -m venv --system-site-packages "$tool_directory/.venv"
"$tool_directory/.venv/bin/python" -m pip install -r "$tool_directory/requirements.txt"
chmod 700 "$tool_directory/ndhcp"
printf '%s\n' 'Installed. Run ./ndhcp doctor, then follow README.md for Cloudflare Access setup.'
