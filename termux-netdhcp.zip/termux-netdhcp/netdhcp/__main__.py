"""Command-line interface. Config generation never starts network services."""

import argparse
from dataclasses import asdict
import json
import os
from pathlib import Path
import subprocess
import sys

from . import __version__
from .config import ConfigError, GatewayConfig


def parser():
    root = argparse.ArgumentParser(description="Termux DHCP/DNS and Cloudflare Access toolkit")
    root.add_argument("--version", action="version", version=__version__)
    commands = root.add_subparsers(dest="command", required=True)
    commands.add_parser("doctor", help="show local network capabilities without changing settings")

    init = commands.add_parser("init", help="create gateway settings (no secrets required)")
    init.add_argument("--team", required=True, help="TEAM from TEAM.cloudflareaccess.com")
    init.add_argument("--aud", required=True, help="Access application AUD tag")
    init.add_argument("--hostname", required=True, help="public DNS name you control")
    init.add_argument("--upstream", help="optional http://127.0.0.1:PORT or http://[::1]:PORT")
    init.add_argument("--port", type=int, default=8787)
    init.add_argument("--allow-identity", action="append", default=[])
    init.add_argument("--output", type=Path, default=Path("gateway.json"))
    init.add_argument("--force", action="store_true")

    dns = commands.add_parser("dns", help="Cloudflare DNS queries and Android setup")
    dns_commands = dns.add_subparsers(dest="action", required=True)
    dns_commands.add_parser("android", help="show system Private DNS instructions")
    query = dns_commands.add_parser("query", help="TLS-verified DoH with primary/alternate fallback")
    query.add_argument("name")
    query.add_argument("--type", choices=["A", "AAAA", "MX", "TXT", "NS", "CNAME", "SOA", "CAA"], default="A")

    dhcp = commands.add_parser("dhcp", help="opt-in IPv4 DHCP on a controlled LAN")
    dhcp_commands = dhcp.add_subparsers(dest="action", required=True)
    create = dhcp_commands.add_parser("config", help="generate a DHCP-only dnsmasq configuration")
    for name in ("interface", "subnet", "server", "router", "start", "end"):
        create.add_argument("--" + name, required=True)
    create.add_argument("--lease", default="12h")
    create.add_argument("--output", type=Path, default=Path("dhcp.conf"))
    create.add_argument("--force", action="store_true")
    serve = dhcp_commands.add_parser("serve", help="root-only foreground DHCP server with preflight checks")
    serve.add_argument("--config", type=Path, default=Path("dhcp.conf"))
    serve.add_argument("--isolated-lan", action="store_true", help="confirm control of this LAN and absence of another DHCP server")
    leases = dhcp_commands.add_parser("leases", help="read local dnsmasq IPv4 leases")
    leases.add_argument("--file", type=Path, default=Path("dhcp-state/dnsmasq.leases"))

    gateway = commands.add_parser("gateway", help="Access-authenticated loopback HTTP gateway")
    gateway_commands = gateway.add_subparsers(dest="action", required=True)
    for action in ("check", "run"):
        sub = gateway_commands.add_parser(action)
        sub.add_argument("--config", type=Path, default=Path("gateway.json"))

    tunnel = commands.add_parser("tunnel", help="named Cloudflare Tunnel configuration and runner")
    tunnel_commands = tunnel.add_subparsers(dest="action", required=True)
    create = tunnel_commands.add_parser("config")
    create.add_argument("--settings", type=Path, default=Path("gateway.json"))
    create.add_argument("--id", required=True, help="tunnel UUID")
    create.add_argument("--credentials", type=Path, help="default: ~/.cloudflared/UUID.json")
    create.add_argument("--output", type=Path, default=Path("cloudflared.yml"))
    create.add_argument("--force", action="store_true")
    run = tunnel_commands.add_parser("run")
    run.add_argument("--config", type=Path, default=Path("cloudflared.yml"))

    traffic = commands.add_parser("traffic-check", help="offline inspection of a sample request target")
    traffic.add_argument("target")
    traffic.add_argument("--body", default="", help="optional sample; avoid real secrets in shell history")
    traffic.add_argument("--threshold", type=int, default=5)
    return root


def main(argv=None):
    arguments = parser().parse_args(argv)
    try:
        if arguments.command == "init":
            config = GatewayConfig(
                team=arguments.team, audience=arguments.aud, hostname=arguments.hostname,
                upstream=arguments.upstream, port=arguments.port,
                allowed_identities=arguments.allow_identity,
            )
            print(config.save(arguments.output, arguments.force))
        elif arguments.command == "doctor":
            from .network import doctor

            print(json.dumps(doctor(), indent=2))
        elif arguments.command == "dns":
            if arguments.action == "android":
                print(
                    "Android 9+: Settings > Network & internet > Private DNS\n"
                    "Choose Private DNS provider hostname: one.one.one.one\n"
                    "For a router's IPv4 DNS settings use 1.1.1.1 and 1.0.0.1.\n"
                    "DHCP DNS options do not set Android's own system resolver.\n"
                    "No Android or Termux settings were changed."
                )
            else:
                from .network import query_dns

                result = query_dns(arguments.name, arguments.type)
                print(json.dumps(result, indent=2))
                return 0 if result["Status"] == 0 else 3
        elif arguments.command == "dhcp":
            from .network import DHCPConfig, serve_dhcp

            if arguments.action == "config":
                config = DHCPConfig(**{name: getattr(arguments, name) for name in (
                    "interface", "subnet", "server", "router", "start", "end", "lease",
                )})
                print(config.save(arguments.output, arguments.force))
            elif arguments.action == "serve":
                serve_dhcp(arguments.config, arguments.isolated_lan)
            else:
                rows = []
                for line in arguments.file.read_text(encoding="utf-8").splitlines():
                    values = line.split()
                    if len(values) >= 5:
                        rows.append(dict(zip(("expires_unix", "mac", "ip", "hostname", "client_id"), values[:5])))
                print(json.dumps(rows, indent=2))
        elif arguments.command == "gateway":
            config = GatewayConfig.load(arguments.config)
            if arguments.action == "check":
                print(json.dumps({"valid": True, "issuer": config.issuer, "settings": asdict(config)}, indent=2))
            else:
                if os.geteuid() == 0:
                    raise ConfigError("run the HTTP gateway as the normal Termux user, not root")
                from .gateway import serve

                print(f"Gateway listening on 127.0.0.1:{config.port}; Access JWT required", file=sys.stderr)
                serve(config)
        elif arguments.command == "tunnel":
            from .tunnel import run_tunnel, save_tunnel

            if arguments.action == "config":
                config = GatewayConfig.load(arguments.settings)
                credentials = arguments.credentials or Path.home() / ".cloudflared" / (arguments.id + ".json")
                print(save_tunnel(config, arguments.id, credentials, arguments.output, arguments.force))
                print("Create an Access application and policy for the whole hostname before starting the tunnel.")
            else:
                if os.geteuid() == 0:
                    raise ConfigError("run Cloudflare Tunnel as the normal Termux user, not root")
                run_tunnel(arguments.config)
        elif arguments.command == "traffic-check":
            from .security import assess_request

            if not 1 <= arguments.threshold <= 100:
                raise ConfigError("threshold must be from 1 to 100")
            assessment = assess_request(arguments.target, arguments.body)
            print(json.dumps({
                **asdict(assessment), "would_block": assessment.score >= arguments.threshold,
                "note": "pattern heuristic only; no identity was authenticated",
            }, indent=2))
        return 0
    except (ConfigError, OSError, subprocess.SubprocessError) as exc:
        print(f"netdhcp: {exc}", file=sys.stderr)
        return 2
    except ImportError as exc:
        print(f"netdhcp: missing dependency ({exc.name}); run bash install-termux.sh", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
