"""Termux DHCP/DNS and Cloudflare Access gateway toolkit."""

__version__ = "1.0.0"
