"""Strict configuration parsing; no shell interpolation or public upstreams."""

from dataclasses import asdict, dataclass, field
import ipaddress
import json
import os
from pathlib import Path
import re
from urllib.parse import urlsplit


class ConfigError(ValueError):
    pass


def hostname(value: str) -> str:
    if not isinstance(value, str):
        raise ConfigError("hostname must be a string")
    value = value.lower().rstrip(".")
    labels = value.split(".")
    if len(value) > 253 or len(labels) < 2 or any(
        not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
        for label in labels
    ):
        raise ConfigError("use a DNS hostname such as net.example.com")
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return value
    raise ConfigError("hostname must be a DNS name, not an IP address")


def private_write(path: Path, content: str, force: bool = False) -> Path:
    """Create 0600 files; replacements use rename, never follow a file symlink."""
    path = path.expanduser().absolute()
    path.parent.mkdir(parents=True, exist_ok=True)
    if not force:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            stream.write(content)
        return path
    import tempfile

    descriptor, temporary = tempfile.mkstemp(prefix=".netdhcp-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            stream.write(content)
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return path


def bounded_int(value, name, minimum, maximum):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ConfigError(f"{name} must be an integer from {minimum} to {maximum}")


@dataclass
class GatewayConfig:
    team: str
    audience: str
    hostname: str
    upstream: str | None = None
    port: int = 8787
    allowed_identities: list[str] = field(default_factory=list)
    global_rps: int = 30
    global_burst: int = 60
    identity_rps: int = 5
    identity_burst: int = 20
    max_body_bytes: int = 1048576
    max_response_bytes: int = 8388608
    risk_threshold: int = 5
    jwt_leeway_seconds: int = 15

    def __post_init__(self):
        if not isinstance(self.team, str) or not re.fullmatch(
            r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", self.team
        ):
            raise ConfigError("team must be your Cloudflare Access team name, without a URL")
        if not isinstance(self.audience, str) or not re.fullmatch(
            r"[A-Za-z0-9_-]{1,256}", self.audience
        ):
            raise ConfigError("audience must be the Access application's AUD tag")
        self.hostname = hostname(self.hostname)
        bounded_int(self.port, "port", 1024, 65535)
        for name in ("global_rps", "global_burst", "identity_rps", "identity_burst"):
            bounded_int(getattr(self, name), name, 1, 10000)
        bounded_int(self.max_body_bytes, "max_body_bytes", 1, 16 * 1048576)
        bounded_int(self.max_response_bytes, "max_response_bytes", 1, 32 * 1048576)
        bounded_int(self.risk_threshold, "risk_threshold", 1, 100)
        bounded_int(self.jwt_leeway_seconds, "jwt_leeway_seconds", 0, 60)
        if not isinstance(self.allowed_identities, list) or len(self.allowed_identities) > 2048:
            raise ConfigError("allowed_identities must be a list of at most 2048 identities")
        for item in self.allowed_identities:
            if not isinstance(item, str) or not re.fullmatch(
                r"(?:user|service):[A-Za-z0-9_.@:-]{1,256}", item
            ):
                raise ConfigError("identities must be user:<signed sub> or service:<signed common_name>")
        if self.upstream is not None:
            if not isinstance(self.upstream, str):
                raise ConfigError("upstream must be a URL or null")
            try:
                parsed = urlsplit(self.upstream)
                address = ipaddress.ip_address(parsed.hostname or "")
                port = parsed.port
            except ValueError as exc:
                raise ConfigError("upstream must use a literal loopback IP and explicit port") from exc
            if (
                parsed.scheme != "http"
                or str(address) not in {"127.0.0.1", "::1"}
                or port is None
                or not 1 <= port <= 65535
                or port == self.port
                or parsed.username is not None
                or parsed.password is not None
                or parsed.path not in {"", "/"}
                or parsed.query
                or parsed.fragment
                or any(ord(char) < 33 for char in self.upstream)
            ):
                raise ConfigError("upstream must be http://127.0.0.1:PORT or http://[::1]:PORT, at a different port")

    @property
    def issuer(self):
        return f"https://{self.team}.cloudflareaccess.com"

    @classmethod
    def load(cls, path: Path):
        try:
            if path.stat().st_size > 65536:
                raise ConfigError("configuration is too large")
            payload = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                raise ConfigError("configuration must be a JSON object")
            return cls(**payload)
        except (TypeError, json.JSONDecodeError) as exc:
            raise ConfigError("invalid or unknown gateway configuration fields") from exc

    def save(self, path: Path, force=False):
        return private_write(path, json.dumps(asdict(self), indent=2) + "\n", force)
