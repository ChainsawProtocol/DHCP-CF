"""DNS diagnostics and opt-in IPv4 DHCP service on a controlled interface."""

from dataclasses import asdict, dataclass
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
from urllib.parse import urlencode
import urllib.request

from .config import ConfigError, private_write


DNS_SERVERS = ("1.1.1.1", "1.0.0.1")
RFC1918 = tuple(ipaddress.ip_network(value) for value in (
    "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16",
))


def query_dns(name, record_type="A", opener=None):
    try:
        ascii_name = name.rstrip(".").encode("idna").decode("ascii")
    except (AttributeError, UnicodeError) as exc:
        raise ConfigError("invalid DNS name") from exc
    if len(ascii_name) > 253 or not ascii_name or any(
        not re.fullmatch(r"[A-Za-z0-9_](?:[A-Za-z0-9_-]{0,61}[A-Za-z0-9_])?", label)
        for label in ascii_name.split(".")
    ):
        raise ConfigError("invalid DNS name")
    if record_type not in {"A", "AAAA", "MX", "TXT", "NS", "CNAME", "SOA", "CAA"}:
        raise ConfigError("unsupported DNS record type")
    from .security import NoRedirect

    opener = opener or urllib.request.build_opener(
        urllib.request.ProxyHandler({}), NoRedirect()
    ).open
    failures = []
    for server in DNS_SERVERS:
        url = f"https://{server}/dns-query?" + urlencode({"name": ascii_name, "type": record_type})
        request = urllib.request.Request(url, headers={"Accept": "application/dns-json"})
        try:
            with opener(request, timeout=4) as response:
                raw = response.read(262145)
            if len(raw) > 262144:
                raise ValueError("oversized DNS answer")
            result = json.loads(raw)
            if not isinstance(result, dict) or type(result.get("Status")) is not int:
                raise ValueError("invalid DNS answer")
            # SERVFAIL, REFUSED and other transient failures try the alternate.
            # NXDOMAIN is a valid negative answer and is returned unchanged.
            if result["Status"] not in {0, 3}:
                raise ValueError("resolver returned a failure")
            return {**result, "resolver": server, "transport": "HTTPS (TLS verified)"}
        except (OSError, ValueError) as exc:
            failures.append(f"{server}: {type(exc).__name__}")
    raise ConfigError("both Cloudflare DNS endpoints failed: " + "; ".join(failures))


@dataclass
class DHCPConfig:
    interface: str
    subnet: str
    server: str
    router: str
    start: str
    end: str
    lease: str = "12h"

    def __post_init__(self):
        if not isinstance(self.interface, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,32}", self.interface):
            raise ConfigError("invalid interface name")
        if self.interface == "lo":
            raise ConfigError("a LAN interface is required")
        try:
            network = ipaddress.IPv4Network(self.subnet, strict=True)
            values = [ipaddress.IPv4Address(getattr(self, key)) for key in ("server", "router", "start", "end")]
        except (ValueError, TypeError) as exc:
            raise ConfigError("DHCP needs a valid IPv4 CIDR and IPv4 addresses") from exc
        if network.prefixlen > 30 or not any(network.subnet_of(lan) for lan in RFC1918):
            raise ConfigError("DHCP subnet must be an RFC1918 LAN with usable hosts")
        if any(value not in network or value in {network.network_address, network.broadcast_address} for value in values):
            raise ConfigError("all DHCP addresses must be usable hosts inside the subnet")
        server, router, start, end = values
        if int(start) > int(end) or int(end) - int(start) >= 4096:
            raise ConfigError("DHCP pool must contain from 1 to 4096 addresses")
        if start <= server <= end or start <= router <= end:
            raise ConfigError("DHCP pool must exclude the server and router")
        if not isinstance(self.lease, str) or not re.fullmatch(r"[1-9][0-9]{0,3}[mhd]", self.lease):
            raise ConfigError("lease must be a bounded duration such as 30m or 12h")

    def render(self, state_directory: Path):
        directory = state_directory.expanduser().absolute()
        # dnsmasq config values are not shell arguments, but still forbid line
        # breaks and commas which could add new directives/arguments.
        if any(char.isspace() or char in ",#\"'\\" for char in str(directory)):
            raise ConfigError("state directory may not contain whitespace, comma, quotes, backslash or #")
        metadata = {"settings": asdict(self), "state_directory": str(directory)}
        network = ipaddress.IPv4Network(self.subnet)
        return "\n".join((
            "# netdhcp-generated-v1 " + json.dumps(metadata, separators=(",", ":")),
            "# IPv4 DHCP only. DNS option 6 does not encrypt client DNS.",
            "# Root is required for Android DHCP and its private lease directory.",
            "port=0", "user=root", "no-resolv", "no-hosts",
            f"interface={self.interface}", "except-interface=lo", "bind-interfaces",
            f"dhcp-range={self.start},{self.end},{network.netmask},{self.lease}",
            f"dhcp-option=option:router,{self.router}",
            "dhcp-option=option:dns-server," + ",".join(DNS_SERVERS),
            f"dhcp-leasefile={directory / 'dnsmasq.leases'}",
            f"pid-file={directory / 'dnsmasq.pid'}", "",
        ))

    def save(self, path: Path, force=False):
        state_directory = path.expanduser().absolute().parent / "dhcp-state"
        state_directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        return private_write(path, self.render(state_directory), force)


def load_generated_dhcp(path):
    if path.stat().st_size > 16384:
        raise ConfigError("DHCP config is too large")
    content = path.read_text(encoding="utf-8")
    prefix = "# netdhcp-generated-v1 "
    if not content.startswith(prefix):
        raise ConfigError("use a config generated by netdhcp dhcp config")
    try:
        payload = json.loads(content.splitlines()[0][len(prefix):])
        config = DHCPConfig(**payload["settings"])
        state_directory = Path(payload["state_directory"])
    except (ValueError, TypeError, KeyError) as exc:
        raise ConfigError("invalid generated DHCP config") from exc
    expected_state = path.expanduser().absolute().parent / "dhcp-state"
    if state_directory != expected_state or state_directory.is_symlink() or config.render(state_directory) != content:
        raise ConfigError("DHCP directives were edited; regenerate the config instead")
    return config, state_directory


def serve_dhcp(path: Path, isolated_lan=False):
    if not isolated_lan:
        raise ConfigError("pass --isolated-lan only for a LAN you control with no other DHCP server")
    if os.geteuid() != 0:
        raise ConfigError("DHCP serving requires root. DNS diagnostics and the gateway do not")
    path = path.expanduser().absolute()
    config, state_directory = load_generated_dhcp(path)
    executable = shutil.which("dnsmasq")
    ip = shutil.which("ip")
    if not executable or not ip:
        raise ConfigError("install dnsmasq and iproute2 first")
    try:
        result = subprocess.run(
            [ip, "-j", "-4", "address", "show", "dev", config.interface],
            check=True, capture_output=True, text=True, timeout=5,
        )
        addresses = json.loads(result.stdout)
        network = ipaddress.IPv4Network(config.subnet)
        found = any(
            item.get("local") == config.server and item.get("prefixlen") == network.prefixlen
            for device in addresses for item in device.get("addr_info", [])
        )
    except (subprocess.SubprocessError, ValueError) as exc:
        raise ConfigError("cannot inspect the LAN interface; check root and Android SELinux restrictions") from exc
    if not found:
        raise ConfigError(f"{config.interface} must already have {config.server}/{network.prefixlen}; the tool does not reconfigure interfaces")
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.bind(("0.0.0.0", 67))
    except OSError as exc:
        raise ConfigError("UDP port 67 is unavailable; check for an existing DHCP server or Android restrictions") from exc
    # Use a validated in-memory snapshot as argv, so a subsequent config-file
    # edit cannot introduce a root-executed dnsmasq directive.
    directives = ["--" + line for line in config.render(state_directory).splitlines() if line and not line.startswith("#")]
    command = [executable, "--conf-file=/dev/null", *directives]
    subprocess.run([*command, "--test"], check=True)
    os.execv(executable, [*command, "--keep-in-foreground", "--log-facility=-"])


def doctor():
    result = {
        "uid": os.geteuid(),
        "dns": list(DNS_SERVERS),
        "binaries": {name: shutil.which(name) for name in ("ip", "cloudflared", "dnsmasq", "getprop")},
        "notes": [
            "DHCP serving needs root and a dedicated LAN interface.",
            "Android may deny interface inspection even when DNS and Tunnel work.",
            "DHCP DNS order is a preference; clients may select either resolver.",
        ],
    }
    for key, arguments in (
        ("addresses", ["ip", "-j", "address", "show"]),
        ("routes", ["ip", "-j", "route", "show"]),
    ):
        if shutil.which(arguments[0]):
            try:
                process = subprocess.run(arguments, capture_output=True, text=True, timeout=5)
                result[key] = json.loads(process.stdout) if process.returncode == 0 else "permission denied or unavailable"
            except (OSError, ValueError, subprocess.SubprocessError):
                result[key] = "unavailable"
    return result
