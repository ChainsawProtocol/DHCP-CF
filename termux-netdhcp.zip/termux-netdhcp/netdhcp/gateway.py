"""Loopback-only authenticated HTTP gateway for a named Cloudflare Tunnel."""

import hashlib
import http.client
import json
import logging
import time
from urllib.parse import quote, urlsplit
import uuid

from flask import Flask, Response, g, jsonify, request
from werkzeug.exceptions import RequestEntityTooLarge

from .security import (
    AccessValidator, AuthenticationError, AuthenticationUnavailable,
    TokenBuckets, assess_request,
)


HOP_HEADERS = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailer", "transfer-encoding", "upgrade", "proxy-connection",
}
METHODS = {"GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"}
AUDIT = logging.getLogger("netdhcp.audit")


def request_target():
    target = request.environ.get("REQUEST_URI") or request.environ.get("RAW_URI")
    if not target:
        target = quote(request.path, safe="/!$&'()*+,;=:@-._~%")
        if request.query_string:
            target += "?" + request.query_string.decode("latin1")
    return target


def proxy_request(config, identity, target, body):
    """A fixed literal loopback upstream; redirects are never followed."""
    parsed = urlsplit(config.upstream)
    connection = http.client.HTTPConnection(parsed.hostname, parsed.port, timeout=5)
    removed = HOP_HEADERS | {"host", "content-length", "expect", "forwarded", "x-request-id"}
    removed |= {item.strip().lower() for item in request.headers.get("Connection", "").split(",")}
    headers = {}
    for name, value in request.headers.items():
        lower = name.lower()
        if lower in removed or lower.startswith(("cf-", "x-forwarded-", "x-netdhcp-")):
            continue
        if lower == "cookie":
            value = "; ".join(
                part.strip() for part in value.split(";")
                if part.strip().split("=", 1)[0].lower() != "cf_authorization"
            )
            if not value:
                continue
        headers[name] = value
    headers["Host"] = parsed.netloc
    headers["X-Forwarded-Host"] = config.hostname
    headers["X-Forwarded-Proto"] = "https"
    headers["X-Netdhcp-Identity"] = identity.key
    headers["X-Request-ID"] = g.request_id
    try:
        connection.request(request.method, target, body=body, headers=headers)
        result = connection.getresponse()
        response_body = result.read(config.max_response_bytes + 1)
        if len(response_body) > config.max_response_bytes:
            raise ValueError("upstream response too large")
        removed = HOP_HEADERS | {"content-length", "server", "date"}
        removed |= {item.strip().lower() for item in (result.getheader("Connection") or "").split(",")}
        response_headers = [
            (name, value) for name, value in result.getheaders()
            if name.lower() not in removed
        ]
        response = Response(response_body, status=result.status, headers=response_headers)
        head_length = result.getheader("Content-Length")
        if request.method == "HEAD" and head_length and head_length.isascii() and head_length.isdigit():
            response.headers["Content-Length"] = head_length
        return response
    finally:
        connection.close()


def create_app(config, validator=None, clock=time.monotonic, transport=None):
    app = Flask(__name__, static_folder=None)
    app.config.update(
        MAX_CONTENT_LENGTH=config.max_body_bytes,
        MAX_FORM_MEMORY_SIZE=65536,
        MAX_FORM_PARTS=100,
    )
    validator = validator if validator is not None else AccessValidator(config)
    transport = transport if transport is not None else proxy_request
    global_limit = TokenBuckets(config.global_rps, config.global_burst, max_keys=1, clock=clock)
    identity_limit = TokenBuckets(config.identity_rps, config.identity_burst, clock=clock)

    def deny(status, reason):
        g.reason = reason
        response = jsonify(error=reason, request_id=g.request_id)
        response.status_code = status
        if status in {429, 503}:
            response.headers["Retry-After"] = "30" if status == 503 else "1"
        return response

    @app.before_request
    def checks():
        g.request_id = uuid.uuid4().hex
        g.started = clock()
        g.identity = None
        g.score = 0
        g.signals = ()
        g.reason = "allowed"
        if not global_limit.consume("all"):
            return deny(429, "global_rate_limit")
        # Host and forwarding headers do not establish identity.
        if request.host.lower() not in {config.hostname, config.hostname + ":443"}:
            return deny(421, "unexpected_host")
        if request.method not in METHODS:
            return deny(405, "method_not_allowed")
        if request.headers.get("Upgrade"):
            return deny(400, "protocol_upgrade_not_supported")
        if request.headers.get("Content-Encoding", "identity").lower() not in {"", "identity"}:
            return deny(415, "compressed_requests_not_supported")
        if request.content_length is not None and request.content_length > config.max_body_bytes:
            return deny(413, "request_too_large")
        try:
            g.identity = validator.validate(request.headers.get("Cf-Access-Jwt-Assertion", ""))
        except AuthenticationError:
            return deny(401, "invalid_or_missing_access_token")
        except AuthenticationUnavailable:
            return deny(503, "access_keys_unavailable")
        if not identity_limit.consume(g.identity.key):
            return deny(429, "identity_rate_limit")
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            origin = request.headers.get("Origin")
            if (origin and origin != "https://" + config.hostname) or request.headers.get("Sec-Fetch-Site") == "cross-site":
                return deny(403, "cross_site_write")
        target = request_target()
        if not isinstance(target, str) or len(target) > 8192 or not target.startswith("/") or target.startswith("//"):
            return deny(400, "invalid_request_target")
        if any(ord(char) < 32 or ord(char) > 126 for char in target) or "#" in target:
            return deny(400, "invalid_request_target")
        # Flask and Waitress each cap the body. No form parser is invoked.
        body = request.get_data(cache=True)
        if len(body) > config.max_body_bytes:
            return deny(413, "request_too_large")
        inspect_body = ""
        if request.mimetype.startswith("text/") or request.mimetype in {
            "application/json", "application/x-www-form-urlencoded", "application/xml",
        }:
            inspect_body = body[:65536].decode("utf-8", "replace")
        risk = assess_request(target, inspect_body)
        g.score, g.signals = risk.score, risk.signals
        if risk.score >= config.risk_threshold:
            return deny(403, "suspicious_request")
        g.target = target
        g.body = body

    @app.errorhandler(RequestEntityTooLarge)
    def too_large(_error):
        return deny(413, "request_too_large")

    @app.after_request
    def audit(response):
        response.headers["X-Request-ID"] = getattr(g, "request_id", "")
        response.headers["X-Content-Type-Options"] = "nosniff"
        if response.status_code >= 400 or config.upstream is None:
            response.headers["Cache-Control"] = "no-store"
        record = {
            "event": "http_request",
            "request_id": getattr(g, "request_id", ""),
            "status": response.status_code,
            "reason": getattr(g, "reason", "http_error"),
            "risk_score": getattr(g, "score", 0),
            "signals": getattr(g, "signals", ()),
            "duration_ms": round(max(0, clock() - getattr(g, "started", clock())) * 1000),
        }
        identity = getattr(g, "identity", None)
        if identity:
            record["identity_hash"] = hashlib.sha256(identity.key.encode()).hexdigest()[:16]
        # Intentionally no URLs, query strings, client headers, bodies or tokens.
        AUDIT.info(json.dumps(record, separators=(",", ":")))
        return response

    @app.route("/", defaults={"path": ""}, methods=sorted(METHODS | {"TRACE", "CONNECT"}), provide_automatic_options=False)
    @app.route("/<path:path>", methods=sorted(METHODS | {"TRACE", "CONNECT"}), provide_automatic_options=False)
    def forward(path):
        if request.path == "/__netdhcp/health":
            return jsonify(ok=True, authenticated=True)
        if config.upstream is None:
            if request.path != "/":
                return deny(404, "not_found")
            return jsonify(
                tool="Termux Network DHCP Tool", authenticated=True,
                identity=g.identity.key,
                dns=["1.1.1.1", "1.0.0.1"],
                upstream_configured=False,
            )
        try:
            return transport(config, g.identity, g.target, g.body)
        except (OSError, ValueError, http.client.HTTPException):
            return deny(502, "upstream_unavailable")

    return app


def serve(config):
    from waitress import serve as waitress_serve

    logging.basicConfig(level=logging.INFO, format="%(message)s")
    # Keep traceback/path logging from Flask out of the audit stream.
    logging.getLogger("waitress").setLevel(logging.WARNING)
    app = create_app(config)
    waitress_serve(
        app, host="127.0.0.1", port=config.port, threads=4,
        connection_limit=64, channel_timeout=30, cleanup_interval=5,
        max_request_header_size=32768,
        max_request_body_size=config.max_body_bytes,
        clear_untrusted_proxy_headers=True,
        expose_tracebacks=False, ident="netdhcp",
    )
