"""Cloudflare Access identity verification and bounded traffic controls."""

from collections import OrderedDict
from dataclasses import dataclass
import json
import re
import threading
import time
from urllib.parse import unquote
import urllib.request

import jwt


class AuthenticationError(Exception):
    pass


class AuthenticationUnavailable(Exception):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class CloudflareKeys:
    """TLS-verified fixed issuer JWKS; no token-provided key URLs are used.

    Cache sets for 5 minutes. Refresh on an unknown kid at most once per
    30 seconds. A failed refresh never accepts an expired key set.
    """

    def __init__(self, issuer, clock=time.monotonic, opener=None):
        self.url = issuer + "/cdn-cgi/access/certs"
        self.clock = clock
        self.open = opener or urllib.request.build_opener(
            urllib.request.ProxyHandler({}), NoRedirect()
        ).open
        self.keys = {}
        self.expires = float("-inf")
        self.last_attempt = float("-inf")
        self.failed = False
        self.lock = threading.Lock()

    def get(self, kid):
        with self.lock:
            now = self.clock()
            if now < self.expires and kid in self.keys:
                return self.keys[kid]
            if now - self.last_attempt < 30:
                if self.failed or now >= self.expires:
                    raise AuthenticationUnavailable("signing keys temporarily unavailable")
                raise AuthenticationError("unknown signing key")
            self.last_attempt = now
            try:
                request = urllib.request.Request(self.url, headers={"Accept": "application/json"})
                with self.open(request, timeout=4) as response:
                    raw = response.read(262145)
                if len(raw) > 262144:
                    raise ValueError("oversized key set")
                payload = json.loads(raw)
                values = payload.get("keys", [])
                if not isinstance(values, list) or not 1 <= len(values) <= 64:
                    raise ValueError("invalid key set")
                keys = {}
                for value in values:
                    if not isinstance(value, dict):
                        continue
                    if value.get("kty") != "RSA" or value.get("alg", "RS256") != "RS256":
                        continue
                    if value.get("use", "sig") != "sig":
                        continue
                    key_id = value.get("kid")
                    if not isinstance(key_id, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,256}", key_id):
                        continue
                    key = jwt.PyJWK.from_dict(value, algorithm="RS256").key
                    if key.key_size < 2048 or key_id in keys:
                        raise ValueError("weak or duplicate key")
                    keys[key_id] = key
                if not keys:
                    raise ValueError("empty key set")
                self.keys = keys
                self.expires = self.clock() + 300
                self.failed = False
            except Exception as exc:
                self.failed = True
                raise AuthenticationUnavailable("cannot refresh Cloudflare signing keys") from exc
            if kid not in self.keys:
                raise AuthenticationError("unknown signing key")
            return self.keys[kid]


@dataclass(frozen=True)
class Identity:
    key: str


class AccessValidator:
    def __init__(self, config, keys=None):
        self.config = config
        self.keys = keys if keys is not None else CloudflareKeys(config.issuer)

    def validate(self, token):
        if not isinstance(token, str) or not 1 <= len(token) <= 16384:
            raise AuthenticationError("missing or oversized Access token")
        try:
            header = jwt.get_unverified_header(token)
            kid = header.get("kid")
            if header.get("alg") != "RS256" or not isinstance(kid, str) or not re.fullmatch(
                r"[A-Za-z0-9_.:-]{1,256}", kid
            ):
                raise AuthenticationError("unsupported token header")
            if any(name in header for name in ("jku", "x5u", "jwk", "crit")):
                raise AuthenticationError("unsupported token header")
            key = self.keys.get(kid)
            claims = jwt.decode(
                token,
                key,
                algorithms=["RS256"],
                audience=self.config.audience,
                issuer=self.config.issuer,
                leeway=self.config.jwt_leeway_seconds,
                options={"require": ["exp", "iat", "iss", "aud", "sub", "type"]},
            )
            if claims["type"] != "app":
                raise AuthenticationError("application token required")
            # CF service-token JWTs intentionally have an empty sub. Their
            # signed common_name identifies the service instead.
            subject = claims["sub"]
            if not isinstance(subject, str):
                raise AuthenticationError("invalid subject")
            raw_id = subject or claims.get("common_name")
            if not isinstance(raw_id, str) or not re.fullmatch(r"[A-Za-z0-9_.@:-]{1,256}", raw_id):
                raise AuthenticationError("missing signed identity")
            identity = Identity(("user:" if subject else "service:") + raw_id)
            if self.config.allowed_identities and identity.key not in self.config.allowed_identities:
                raise AuthenticationError("identity not allowed locally")
            return identity
        except jwt.PyJWTError as exc:
            raise AuthenticationError("invalid Access token") from exc


class TokenBuckets:
    """Thread-safe monotonic token buckets with bounded identity storage.

    A full table denies new identities rather than evicting active buckets.
    Idle eviction only occurs after buckets would already have refilled.
    """

    def __init__(self, rate, burst, max_keys=2048, clock=time.monotonic):
        self.rate = rate
        self.burst = burst
        self.max_keys = max_keys
        self.clock = clock
        self.idle_ttl = max(600, burst / rate)
        self.buckets = OrderedDict()
        self.lock = threading.Lock()

    def consume(self, key):
        with self.lock:
            now = self.clock()
            while self.buckets:
                oldest = next(iter(self.buckets))
                if now - self.buckets[oldest][1] <= self.idle_ttl:
                    break
                self.buckets.popitem(last=False)
            bucket = self.buckets.pop(key, None)
            if bucket is None:
                if len(self.buckets) >= self.max_keys:
                    return False
                tokens, updated = float(self.burst), now
            else:
                tokens, updated = bucket
            tokens = min(self.burst, tokens + max(0, now - updated) * self.rate)
            allowed = tokens >= 1
            self.buckets[key] = (tokens - 1 if allowed else tokens, now)
            return allowed


@dataclass(frozen=True)
class Assessment:
    score: int
    signals: tuple[str, ...]


def assess_request(target: str, body: str = "") -> Assessment:
    """Transparent heuristics, not a claim to classify all malicious traffic."""
    decoded_target = target.lower()
    for _ in range(3):
        decoded_target = unquote(decoded_target)
    text = (target + "\n" + body[:65536]).lower()
    for _ in range(3):
        decoded = unquote(text)
        if decoded == text:
            break
        text = decoded
    rules = (
        ("path_traversal", 5, r"(?:^|[/\\])\.\.(?:[/\\]|$|[?&\s])"),
        ("secret_file_probe", 5, r"/(?:\.git|\.svn)(?:[/\\]|$|[?\s])|/\.env(?:[./?\s]|$)"),
        ("nul_or_control", 5, r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]"),
        ("script_markup", 3, r"<\s*script\b|javascript\s*:"),
        ("sql_union", 3, r"\bunion\s+(?:all\s+)?select\b"),
        ("sql_delay", 3, r"\b(?:sleep|benchmark)\s*\("),
    )
    signals = tuple(name for name, _, pattern in rules if re.search(pattern, text))
    score = sum(weight for name, weight, _ in rules if name in signals)
    if re.search(r"[\x00-\x1f\x7f]", decoded_target) and "nul_or_control" not in signals:
        signals += ("nul_or_control",)
        score += 5
    return Assessment(score, signals)
