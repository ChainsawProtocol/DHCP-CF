"""Security behavior and network configuration tests; no external network."""

from dataclasses import replace
import io
import http.client
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import Mock, patch
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from cryptography.hazmat.primitives.asymmetric import rsa
import jwt

from netdhcp.config import ConfigError, GatewayConfig
from netdhcp.gateway import create_app
from netdhcp.network import DHCPConfig, load_generated_dhcp, query_dns, serve_dhcp
from netdhcp.security import (
    AccessValidator, AuthenticationError, AuthenticationUnavailable,
    CloudflareKeys, TokenBuckets, assess_request,
)
from netdhcp.tunnel import render_tunnel


class Fixtures(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.public = cls.private.public_key()

    def setUp(self):
        self.config = GatewayConfig(team="my-team", audience="my-aud", hostname="net.example.com")
        self.keys = Mock()
        self.keys.get.return_value = self.public
        self.validator = AccessValidator(self.config, self.keys)

    def token(self, changes=None, remove=(), headers=None, key=None):
        claims = {
            "type": "app", "sub": "user-123", "aud": [self.config.audience],
            "iss": self.config.issuer, "iat": int(time.time()) - 1,
            "exp": int(time.time()) + 120,
        }
        claims.update(changes or {})
        for field in remove:
            del claims[field]
        return jwt.encode(claims, key or self.private, algorithm="RS256", headers={"kid": "key-1", **(headers or {})})


class ConfigTests(unittest.TestCase):
    def test_only_literal_loopback_upstreams(self):
        for value in (
            "http://example.com:8080", "http://192.168.1.1:8080", "http://localhost:8080",
            "https://127.0.0.1:8080", "http://127.0.0.1:8787", "http://user:pass@127.0.0.1:8080",
            "http://127.0.0.1:8080/path", "http://127.0.0.1:8080?x=1", "http://127.0.0.1:8080\n",
        ):
            with self.subTest(value=value), self.assertRaises(ConfigError):
                GatewayConfig(team="team", audience="aud", hostname="net.example.com", upstream=value)
        config = GatewayConfig(team="team", audience="aud", hostname="net.example.com", upstream="http://[::1]:8080")
        self.assertEqual(config.upstream, "http://[::1]:8080")

    def test_untrusted_issuer_and_types_rejected(self):
        for team in ("https://evil.example", "evil.cloudflareaccess.com", "a\nx", "-a"):
            with self.subTest(team=team), self.assertRaises(ConfigError):
                GatewayConfig(team=team, audience="aud", hostname="net.example.com")
        for overrides in ({"port": True}, {"risk_threshold": 0}, {"allowed_identities": "*"}):
            with self.subTest(overrides=overrides), self.assertRaises(ConfigError):
                GatewayConfig(team="team", audience="aud", hostname="net.example.com", **overrides)

    def test_config_file_permissions_and_no_implicit_overwrite(self):
        config = GatewayConfig(team="team", audience="aud", hostname="net.example.com")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "gateway.json"
            config.save(path)
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            self.assertEqual(GatewayConfig.load(path), config)
            with self.assertRaises(FileExistsError):
                config.save(path)

    def test_tunnel_matches_access_settings(self):
        config = GatewayConfig(team="team", audience="aud", hostname="net.example.com")
        result = render_tunnel(config, "8d8f132c-05f9-4dbc-9182-9342c9eb63f8", Path("/tmp/id.json"))
        self.assertIn("required: true", result)
        self.assertIn('teamName: "team"', result)
        self.assertIn('          - "aud"', result)
        self.assertIn("http://127.0.0.1:8787", result)
        self.assertTrue(result.endswith("  - service: http_status:404\n"))
        with self.assertRaises(ConfigError):
            render_tunnel(config, "bad\nconfig", Path("/tmp/id.json"))


class AuthenticationTests(Fixtures):
    def test_valid_user_and_service_tokens(self):
        self.assertEqual(self.validator.validate(self.token()).key, "user:user-123")
        token = self.token({"sub": "", "common_name": "client-id.access"})
        self.assertEqual(self.validator.validate(token).key, "service:client-id.access")

    def test_invalid_claims_rejected(self):
        cases = [
            {"aud": ["other-app"]}, {"iss": "https://evil.cloudflareaccess.com"},
            {"exp": int(time.time()) - 60}, {"iat": int(time.time()) + 120},
            {"nbf": int(time.time()) + 120}, {"sub": ""}, {"sub": "a\r\nb: c"},
            {"type": "org"},
        ]
        for claims in cases:
            with self.subTest(claims=claims), self.assertRaises(AuthenticationError):
                self.validator.validate(self.token(claims))
        for field in ("exp", "iat", "iss", "aud", "sub", "type"):
            with self.subTest(missing=field), self.assertRaises(AuthenticationError):
                self.validator.validate(self.token(remove=(field,)))

    def test_wrong_signature(self):
        other_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        with self.assertRaises(AuthenticationError):
            self.validator.validate(self.token(key=other_key))

    def test_unsupported_algorithm_and_key_url_fail_before_key_lookup(self):
        for token in (
            jwt.encode({"sub": "fake"}, "not-a-real-access-key-at-all-long-secret", algorithm="HS256", headers={"kid": "key-1"}),
            self.token(headers={"jku": "https://evil.example/keys"}),
            "not-a-jwt", "", "a" * 16385,
        ):
            with self.subTest(token=token[:25]), self.assertRaises(AuthenticationError):
                self.validator.validate(token)
        self.keys.get.assert_not_called()

    def test_optional_local_allowlist(self):
        config = replace(self.config, allowed_identities=["user:someone-else"])
        with self.assertRaises(AuthenticationError):
            AccessValidator(config, self.keys).validate(self.token())


class KeyCacheTests(Fixtures):
    def jwks(self, kid="key-1"):
        value = jwt.algorithms.RSAAlgorithm.to_jwk(self.public, as_dict=True)
        value.update(kid=kid, use="sig", alg="RS256")
        return json.dumps({"keys": [value]}).encode()

    def test_unknown_kid_cannot_trigger_unbounded_fetches(self):
        now = [100.0]
        opener = Mock(side_effect=lambda *a, **k: io.BytesIO(self.jwks()))
        keys = CloudflareKeys(self.config.issuer, clock=lambda: now[0], opener=opener)
        keys.get("key-1")
        for index in range(20):
            with self.assertRaises(AuthenticationError):
                keys.get(f"unknown-{index}")
        self.assertEqual(opener.call_count, 1)
        now[0] += 31
        with self.assertRaises(AuthenticationError):
            keys.get("another-unknown")
        self.assertEqual(opener.call_count, 2)
        self.assertEqual(opener.call_args.args[0].full_url, self.config.issuer + "/cdn-cgi/access/certs")

    def test_rotation_refreshes_after_cooldown(self):
        now = [100.0]
        opener = Mock(side_effect=[io.BytesIO(self.jwks()), io.BytesIO(self.jwks("key-2"))])
        keys = CloudflareKeys(self.config.issuer, clock=lambda: now[0], opener=opener)
        keys.get("key-1")
        now[0] += 31
        self.assertEqual(keys.get("key-2").public_numbers(), self.public.public_numbers())

    def test_expired_key_set_and_network_failure_fail_closed(self):
        now = [100.0]
        opener = Mock(side_effect=[io.BytesIO(self.jwks()), OSError("offline")])
        keys = CloudflareKeys(self.config.issuer, clock=lambda: now[0], opener=opener)
        keys.get("key-1")
        now[0] += 301
        with self.assertRaises(AuthenticationUnavailable):
            keys.get("key-1")
        with self.assertRaises(AuthenticationUnavailable):
            keys.get("key-1")
        self.assertEqual(opener.call_count, 2)


class TrafficTests(unittest.TestCase):
    def test_encoded_traversal_and_secret_probes(self):
        for target in ("/../../etc/passwd", "/%252e%252e%252fsecret", "/.git/config", "/.env", "/..", "/?q=%0d%0aInjected:yes"):
            with self.subTest(target=target):
                self.assertGreaterEqual(assess_request(target, "sample body").score, 5)
        self.assertEqual(assess_request("/api/items?q=hello").score, 0)

    def test_multiple_signals_add_up(self):
        result = assess_request("/?q=UNION%20SELECT&x=<script>")
        self.assertEqual(result.score, 6)
        self.assertIn("sql_union", result.signals)

    def test_bucket_refill_and_bounded_identity_storage(self):
        now = [0.0]
        bucket = TokenBuckets(2, 2, max_keys=1, clock=lambda: now[0])
        self.assertTrue(bucket.consume("a"))
        self.assertTrue(bucket.consume("a"))
        self.assertFalse(bucket.consume("a"))
        self.assertFalse(bucket.consume("b"))
        now[0] += 0.5
        self.assertTrue(bucket.consume("a"))
        self.assertFalse(bucket.consume("a"))
        now[0] += 601
        self.assertTrue(bucket.consume("b"))


class DNSTests(unittest.TestCase):
    def test_https_primary_and_alternate_fallback(self):
        opener = Mock(side_effect=[OSError("unreachable"), io.BytesIO(b'{"Status":0,"Answer":[]}')])
        result = query_dns("example.com", opener=opener)
        self.assertEqual(result["resolver"], "1.0.0.1")
        self.assertTrue(opener.call_args_list[0].args[0].full_url.startswith("https://1.1.1.1/dns-query?"))
        self.assertTrue(opener.call_args_list[1].args[0].full_url.startswith("https://1.0.0.1/dns-query?"))
        self.assertEqual(opener.call_args_list[0].args[0].get_header("Accept"), "application/dns-json")

    def test_nxdomain_is_not_disguised_as_network_failure(self):
        opener = Mock(return_value=io.BytesIO(b'{"Status":3}'))
        self.assertEqual(query_dns("does-not-exist.example", opener=opener)["Status"], 3)
        self.assertEqual(opener.call_count, 1)

    def test_both_servers_fail_without_plaintext_fallback(self):
        opener = Mock(side_effect=OSError("unreachable"))
        with self.assertRaises(ConfigError):
            query_dns("example.com", opener=opener)
        self.assertEqual(opener.call_count, 2)

    def test_servfail_tries_alternate(self):
        opener = Mock(side_effect=[io.BytesIO(b'{"Status":2}'), io.BytesIO(b'{"Status":0}')])
        self.assertEqual(query_dns("example.com", opener=opener)["resolver"], "1.0.0.1")

    def test_invalid_dns_name_rejected_before_network(self):
        opener = Mock()
        with self.assertRaises(ConfigError):
            query_dns("example.com\nmalicious", opener=opener)
        opener.assert_not_called()


class DHCPTests(unittest.TestCase):
    def setUp(self):
        self.config = DHCPConfig(
            interface="eth0", subnet="192.168.50.0/24", server="192.168.50.1",
            router="192.168.50.1", start="192.168.50.50", end="192.168.50.100",
        )

    def test_advertises_requested_dns_and_disables_dns_server(self):
        result = self.config.render(Path("/tmp/dhcp-state"))
        self.assertIn("dhcp-option=option:dns-server,1.1.1.1,1.0.0.1", result)
        self.assertIn("\nport=0\n", result)
        self.assertIn("dhcp-range=192.168.50.50,192.168.50.100,255.255.255.0,12h", result)
        self.assertNotIn("dhcp-authoritative", result)

    def test_bad_pool_and_interface_rejected(self):
        for changes in (
            {"start": "192.168.50.0"}, {"end": "192.168.50.255"},
            {"start": "192.168.50.100", "end": "192.168.50.50"},
            {"server": "192.168.50.60"}, {"router": "192.168.51.1"},
            {"subnet": "1.1.1.0/24"}, {"interface": "eth0\ndhcp-script=/tmp/evil"},
            {"interface": "lo"}, {"lease": "12h\nuser=root"},
        ):
            with self.subTest(changes=changes), self.assertRaises(ConfigError):
                replace(self.config, **changes)

    def test_modified_dnsmasq_directives_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "dhcp.conf"
            self.config.save(path)
            loaded, state = load_generated_dhcp(path)
            self.assertEqual(loaded, self.config)
            self.assertEqual(state.name, "dhcp-state")
            path.write_text(path.read_text() + "dhcp-script=/tmp/evil\n")
            with self.assertRaises(ConfigError):
                load_generated_dhcp(path)

    def test_root_and_lan_confirmation_required(self):
        with self.assertRaises(ConfigError):
            serve_dhcp(Path("missing.conf"))
        with patch("netdhcp.network.os.geteuid", return_value=10000):
            with self.assertRaises(ConfigError):
                serve_dhcp(Path("missing.conf"), isolated_lan=True)


class GatewayTests(Fixtures):
    def client(self, config=None, transport=None, clock=time.monotonic):
        config = config or self.config
        app = create_app(config, AccessValidator(config, self.keys), clock=clock, transport=transport)
        app.testing = True
        return app.test_client()

    def headers(self, **extra):
        return {"Host": self.config.hostname, "Cf-Access-Jwt-Assertion": self.token(), **extra}

    def test_no_token_or_forged_cloudflare_headers_cannot_authenticate(self):
        client = self.client()
        response = client.get("/", headers={
            "Host": self.config.hostname, "Cf-Connecting-IP": "1.2.3.4",
            "Cf-Access-Authenticated-User-Email": "admin@example.com", "Cf-Ray": "forged",
        })
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.headers["Cache-Control"], "no-store")

    def test_valid_login_and_health(self):
        client = self.client()
        self.assertEqual(client.get("/", headers=self.headers()).json["identity"], "user:user-123")
        self.assertEqual(client.get("/__netdhcp/health", headers=self.headers()).status_code, 200)
        self.assertEqual(client.get("/__netdhcp/health", headers={"Host": self.config.hostname}).status_code, 401)

    def test_host_method_upgrade_and_size_checks(self):
        client = self.client()
        self.assertEqual(client.get("/", headers={**self.headers(), "Host": "evil.example"}).status_code, 421)
        self.assertEqual(client.open("/", method="TRACE", headers=self.headers()).status_code, 405)
        self.assertEqual(client.get("/", headers=self.headers(Upgrade="websocket")).status_code, 400)
        self.assertEqual(client.post("/", data=b"fake-gzip", headers=self.headers(**{"Content-Encoding": "gzip"})).status_code, 415)
        self.assertEqual(client.post("/", data=b"x" * (self.config.max_body_bytes + 1), headers=self.headers()).status_code, 413)

    def test_signed_identity_rate_limit_ignores_spoofed_client_ips(self):
        client = self.client(replace(self.config, identity_burst=2), clock=lambda: 100)
        statuses = [
            client.get("/", headers=self.headers(**{"Cf-Connecting-IP": str(index)})).status_code
            for index in range(3)
        ]
        self.assertEqual(statuses, [200, 200, 429])

    def test_global_limit_also_covers_unauthenticated_attempts(self):
        client = self.client(replace(self.config, global_burst=2), clock=lambda: 100)
        results = [client.get("/", headers={"Host": self.config.hostname}).status_code for _ in range(3)]
        self.assertEqual(results, [401, 401, 429])

    def test_authenticated_suspicious_requests_are_still_blocked(self):
        client = self.client()
        response = client.get("/%252e%252e/secret", headers=self.headers())
        self.assertEqual(response.status_code, 403)
        self.assertEqual(response.json["error"], "suspicious_request")

    def test_cross_site_writes_blocked(self):
        client = self.client()
        response = client.post("/", data="hello", headers=self.headers(Origin="https://evil.example"))
        self.assertEqual(response.status_code, 403)

    def test_key_server_failure_denies_forwarding(self):
        self.keys.get.side_effect = AuthenticationUnavailable()
        client = self.client()
        response = client.get("/", headers=self.headers())
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.headers["Retry-After"], "30")

    def test_logs_do_not_contain_credentials_query_or_body(self):
        client = self.client()
        token = self.token()
        with self.assertLogs("netdhcp.audit", level="INFO") as logs:
            client.post("/?password=SECRET_QUERY", data="SECRET_BODY", headers={
                "Host": self.config.hostname, "Cf-Access-Jwt-Assertion": token,
            })
        output = " ".join(logs.output)
        for secret in (token, "SECRET_QUERY", "SECRET_BODY", "user-123"):
            self.assertNotIn(secret, output)
        self.assertIn("identity_hash", output)

    def test_waitress_socket_verifies_real_signed_token(self):
        from waitress import create_server

        server = create_server(
            create_app(self.config, self.validator), host="127.0.0.1", port=0,
            threads=2, asyncore_loop_timeout=0.1,
            clear_untrusted_proxy_headers=True, expose_tracebacks=False,
        )
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        try:
            for headers, status in (
                (self.headers(), 200),
                ({"Host": self.config.hostname, "Cf-Connecting-IP": "1.1.1.1"}, 401),
            ):
                connection = http.client.HTTPConnection("127.0.0.1", int(server.effective_port), timeout=3)
                try:
                    connection.request("GET", "/", headers=headers)
                    result = connection.getresponse()
                    self.assertEqual(result.status, status)
                    result.read()
                finally:
                    connection.close()
        finally:
            server.close()
            thread.join(timeout=3)
        self.assertFalse(thread.is_alive())

    def test_real_loopback_proxy_preserves_body_and_strips_untrusted_headers(self):
        observed = {}

        class Upstream(BaseHTTPRequestHandler):
            def do_HEAD(self):
                self.send_response(200)
                self.send_header("Content-Length", "1234")
                self.end_headers()

            def do_GET(self):
                if self.path == "/redirect":
                    self.send_response(302)
                    self.send_header("Location", "http://outside.example/not-followed")
                    self.end_headers()
                else:
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"x" * 32)

            def do_POST(self):
                observed["path"] = self.path
                observed["headers"] = {k.lower(): v for k, v in self.headers.items()}
                observed["body"] = self.rfile.read(int(self.headers["Content-Length"]))
                self.send_response(201)
                self.send_header("Set-Cookie", "first=a; HttpOnly")
                self.send_header("Set-Cookie", "second=b; HttpOnly")
                self.send_header("Connection", "close, X-Private-Hop")
                self.send_header("X-Private-Hop", "remove-me")
                self.end_headers()
                self.wfile.write(b"created")

            def log_message(self, *_args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Upstream)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            config = replace(self.config, upstream=f"http://127.0.0.1:{server.server_port}")
            client = self.client(config)
            client.set_cookie("CF_Authorization", "EDGE_SECRET", domain=self.config.hostname)
            client.set_cookie("session", "APP_SESSION", domain=self.config.hostname)
            response = client.post("/api/items?name=hello%20world", data=b'{"ok":true}', headers=self.headers(**{
                "Content-Type": "application/json", "Cf-Access-Client-Secret": "SERVICE_SECRET",
                "X-Netdhcp-Identity": "user:fake", "X-Forwarded-For": "evil",
                "X-Request-ID": "forged-id",
                "Connection": "keep-alive, X-Private-Hop", "X-Private-Hop": "remove-me",
            }))
            self.assertEqual(response.status_code, 201)
            self.assertEqual(response.data, b"created")
            self.assertEqual(len(response.headers.getlist("Set-Cookie")), 2)
            self.assertNotIn("X-Private-Hop", response.headers)
            self.assertEqual(observed["path"], "/api/items?name=hello%20world")
            self.assertEqual(observed["body"], b'{"ok":true}')
            self.assertEqual(observed["headers"]["x-netdhcp-identity"], "user:user-123")
            self.assertEqual(observed["headers"]["x-forwarded-host"], self.config.hostname)
            self.assertEqual(observed["headers"]["x-request-id"], response.headers["X-Request-ID"])
            self.assertEqual(observed["headers"]["cookie"], "session=APP_SESSION")
            for name in ("cf-access-jwt-assertion", "cf-access-client-secret", "x-forwarded-for", "x-private-hop"):
                self.assertNotIn(name, observed["headers"])
            head = client.head("/", headers=self.headers())
            self.assertEqual(head.status_code, 200)
            self.assertEqual(head.headers["Content-Length"], "1234")
            self.assertEqual(head.data, b"")
            redirect = client.get("/redirect", headers=self.headers())
            self.assertEqual(redirect.status_code, 302)
            self.assertEqual(redirect.headers["Location"], "http://outside.example/not-followed")
            capped_client = self.client(replace(config, max_response_bytes=16))
            self.assertEqual(capped_client.get("/large", headers=self.headers()).status_code, 502)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)


if __name__ == "__main__":
    unittest.main()
