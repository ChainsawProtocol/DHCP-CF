# Authentication and request assessment algorithms

## A. Establish a verified Cloudflare Access identity

1. Bind the gateway to `127.0.0.1`. Accept only the configured public Host.
2. Apply a global token bucket before JWT verification, including to requests
   missing credentials. Enforce method, encoding and size restrictions.
3. Read `Cf-Access-Jwt-Assertion`. Reject missing/oversized/malformed tokens.
4. Require `alg=RS256` and a bounded `kid`. Reject token-supplied key URLs,
   embedded JWKs and critical-header extensions. Unverified fields only
   select a key; they never establish identity.
5. Fetch keys exclusively from the configured team issuer's
   `/cdn-cgi/access/certs` endpoint over certificate-verified HTTPS.
   Redirects and environment-configured proxies are disabled. Accept RSA
   signing keys of at least 2048 bits. Cache a successful key set for 300
   seconds. Refresh an unknown key ID at most once per 30 seconds, using
   one locked refresh across threads. A refresh failure denies requests
   requiring unavailable keys. Expired cache entries are not used.
6. Use PyJWT and cryptography to verify the signature, issuer, application
   audience, expiry, issuance time, and `nbf` when present. Require `exp`,
   `iat`, `iss`, `aud`, `sub` and `type`. Allow 15 seconds of clock skew.
   Require the application token type `app`.
7. For a nonempty signed `sub`, set identity to `user:<sub>`. Cloudflare
   service tokens can have empty `sub`; use their signed `common_name` as
   `service:<common_name>`. Require a bounded, header-safe identity string.
8. If a local identity allowlist is configured, require a match. Otherwise,
   the Access application's policies determine which identities qualify.
9. Apply the per-identity bucket using that verified identity. Unsigned
   `Cf-Connecting-IP`, `Cf-Ray`, email and forwarded headers never establish
   identity or choose the per-identity counter.

JWTs are bearer credentials and can be replayed until expiry if stolen.
Offline JWT verification does not query session revocation on each request.
Use suitable Access session duration, identity-provider policies and device
security for your application. A key rotation can cause a brief rejection
until the 30-second refresh cooldown expires.

## B. Token bucket

For a bucket with refill rate `r`, capacity `b`, previous balance `t`, and
elapsed monotonic time `dt`:

```text
available = min(b, t + r * max(0, dt))
if available >= 1:
    balance = available - 1
    allow
else:
    balance = available
    reject with HTTP 429
```

All modifications are protected by a lock. The identity table contains at
most 2048 entries. A full table rejects new identities rather than evicting
active counters. Idle entries expire only after their bucket would already
have fully refilled. Buckets are local to one gateway process and reset
when it restarts. They are not distributed DDoS protection.

## C. Suspicious request score

Lowercase the target and the first 64 KiB of a text/JSON/XML/form body.
Percent-decode up to three times for inspection only; forward the original
request unchanged. Count each matching rule once:

| Signal | Score |
| --- | ---: |
| Parent-directory traversal pattern | 5 |
| Probe for `.git`, `.svn` or `.env` | 5 |
| NUL/control characters; CR/LF are also checked in the target | 5 |
| Script markup or `javascript:` | 3 |
| SQL `UNION SELECT` pattern | 3 |
| SQL delay-function pattern | 3 |

Reject scores of 5 or greater with HTTP 403. Lower scores remain visible
in the audit record. Reject cross-origin browser write requests when an
Origin header names another origin or Fetch Metadata marks them cross-site.
Applications still need their own CSRF defenses, authorization and input
validation.

This score is a small transparent heuristic, not a probability of malicious
intent. It can reject legitimate developer documentation and miss attacks,
including alternate encodings, multipart/binary content and text beyond
the inspection limit. Tune it for the application and review false positives.

## D. Forward only to the fixed local application

1. Use the configured literal loopback host and port for every connection.
   Never use a URL from the client as an upstream. Never follow redirects.
2. Remove hop-by-hop headers, including headers named by `Connection`.
   Strip client `CF-*`, forwarding, toolkit identity and request-ID headers.
   Remove the Access authorization cookie while preserving application
   cookies. Generate a new request ID.
3. Set trusted public-host/protocol metadata from configuration and the
   identity marker from verified claims. Do not synthesize a client IP.
4. Send the unchanged target/body and cap the buffered response. Keep
   multiple Set-Cookie response headers intact. Close the upstream socket
   after each request.
5. Emit the audit record with outcome, scores, request ID, duration and an
   identity hash. Do not log credentials, raw identity, URL or body.

The upstream's identity marker is safe only within the deployment's local
trust boundary. Another local process that can reach the upstream directly
can supply its own headers. Authenticate the upstream too when needed.
