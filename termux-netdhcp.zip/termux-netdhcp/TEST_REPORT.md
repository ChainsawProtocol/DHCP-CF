# Build verification

Verified on 24 October 2026 with Python 3.12.14 on Linux.

**Result: 35 automated tests passed.**

Test dependencies: PyJWT 2.15.1, cryptography 50.0.2, Flask 3.1.3,
Werkzeug 3.1.9, Waitress 3.0.2. Tests use temporary generated RSA keys
and synthetic identities, not real Cloudflare credentials.

Verified behavior:

- RSA-signed user and service JWTs; rejection of wrong signatures,
  algorithms, key URLs, issuer, audience, missing claims, expired/future
  tokens and denied local identities.
- Fixed-issuer JWKS fetch, bounded unknown-key refreshes, key rotation,
  cache expiry, unavailable signing keys and fail-closed handling.
- Monotonic token-bucket refill, bounded identity storage, global limiting
  of unauthenticated requests and identity limiting independent of fake IPs.
- Encoded traversal, secret-file probes, target control characters,
  cumulative pattern scores, cross-site writes and request limits.
- Primary/alternate HTTPS DNS fallback, SERVFAIL retry, NXDOMAIN semantics,
  input rejection and no plaintext fallback, using mocked DNS responses.
- DHCP subnet/pool/interface validation, requested DNS option, DNS service
  disabled, root/controlled-LAN gating and rejection of extra directives.
- A real local HTTP proxy exchange: original target/body forwarding,
  forged identity/request-ID and Cloudflare credential removal,
  connection-specific header removal, multiple Set-Cookie headers,
  HEAD content length, redirect pass-through and response size cap.
- A real Waitress socket exchange with a locally signed token accepted
  and forged Cloudflare headers rejected.
- Audit output omits tokens, raw identity, query and body content.

Additional checks passed:

- Bash syntax for the launcher and installer.
- Python compilation for the package and tests.
- Eight command-line smoke checks: version, doctor, Android DNS help,
  gateway configuration generation/validation, offline traffic score,
  DHCP configuration generation, and Tunnel configuration generation.
- Generated YAML parses and contains matching Access settings, explicit
  Host routing and the fallback 404 rule.

Not verified here:

- Installer execution on a live Termux/Android device or availability of
  packages in every Termux mirror.
- Live Cloudflare login, Access policies, credentials, tunnel ingress
  validation with the cloudflared executable, or public HTTPS routing.
- Live Cloudflare DoH connectivity/certificates from the target phone.
- dnsmasq executable syntax validation, root/SELinux permissions, actual
  DHCP packet exchange, Android hotspot interaction or client DNS choice.

The DHCP runner performs its own dnsmasq syntax and interface preflight on
the target device. Complete the real-device checks in README.md before
depending on the deployment.
